import picas_fijas as pf
import random as rdm

def ejecutar_picas_y_fijas(numero_secreto:int,turnos:int)->bool:
    print("Le quedan "+str(turnos)+" turnos.")
    numero_propuesto=int(input("Ingrese su número a jugar: "))
    fijas= pf.contar_fijas(numero_secreto, numero_propuesto)
    picas= pf.contar_picas(numero_secreto, numero_propuesto)
    print("Obtuvo "+str(picas)+" picas")
    print("Obtuvo "+str(fijas)+" fijas")
    if fijas==4:
        return True
    else:
        return False

def iniciar_aplicacion()->None:
    numero_s= rdm.randint(1000,9999)
    print("Bienvenido a picas y fijas")
    print(numero_s)
    turnos=5
    
    if ejecutar_picas_y_fijas(numero_s, turnos):
        print("Has ganado, felicitaciones")
    else:
        turnos-=1
        if ejecutar_picas_y_fijas(numero_s, turnos):
            print("Has ganado, felicitaciones")
        else:
            turnos-=1
            if ejecutar_picas_y_fijas(numero_s, turnos):
                print("Has ganado, felicitaciones")
            else:
                turnos-=1
                if ejecutar_picas_y_fijas(numero_s, turnos):
                    print("Has ganado, felicitaciones")
                else:
                    turnos-=1
                    if ejecutar_picas_y_fijas(numero_s, turnos):
                        print("Has ganado, felicitaciones")
                    else:
                        if ejecutar_picas_y_fijas(numero_s, turnos):
                            print("Has ganado, felicitaciones")
                        else:
                            print("Has perdido, intentalo de nuevo")
                            
iniciar_aplicacion()

